### R code from vignette source 'usingPCxNdb.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: queries
###################################################
# Use the pcxn package to select a query gene set from
# a specific collection while requesting the 10 most
# correlated neighbors and specific cut-offs for
# minimum absolute correlation and maximum p-value

library(pcxn)

pcxn.obj <- pcxn.explore(collection = "pathprint",
                  query_geneset = "Alzheimer's disease (KEGG)",
                  top = 10,
                  min_abs_corr = 0.05,
                  max_pval = 0.05)

# Use the pcxn package to select one or two oathway groups from a specific
# collection while requesting the 10 most correlated neighbors and specific
# cut-offs for minimum absolute correlation and maximum p-value

pcxn.obj <- pcxn.analyze("pathprint",c("ABC transporters (KEGG)",
                                       "ACE Inhibitor Pathway (Wikipathways)",
                                       "AR down reg. targets (Netpath)"),
                         c("DNA Repair (Reactome)"), 10, 0.05, 0.05)


###################################################
### code chunk number 2: pcxn.gene_members
###################################################
# Use the pcxn package to select pathway from any collection and get it's
# gene members as a list

library(pcxn)

gene_member_list <- pcxn.gene_members("Alzheimer's disease (KEGG)")


###################################################
### code chunk number 3: pcxn.heatmap
###################################################
# Use the pcxn package to draw a heatmap based on a pcxn object

library(pcxn)

# Creare the pcxn.obj we need as an input
pcxn.obj <- pcxn.analyze("pathprint",c("ABC transporters (KEGG)",
                                       "ACE Inhibitor Pathway (Wikipathways)",
                                       "AR down reg. targets (Netpath)"),
                         c("DNA Repair (Reactome)"), 10, 0.05, 0.05)

heatmap <- pcxn.heatmap(pcxn.obj, "complete")


###################################################
### code chunk number 4: pcxn.network
###################################################
# Use the pcxn package to draw a heatmap based on a pcxn object

library(pcxn)

pcxn.obj <- pcxn.analyze("pathprint",c("ABC transporters (KEGG)",
                                       "ACE Inhibitor Pathway (Wikipathways)",
                                       "AR down reg. targets (Netpath)"),
                         c("DNA Repair (Reactome)"), 10, 0.05, 0.05)

network <- pcxn.network(pcxn.obj)


