# pathprint
Pathway fingerprinting for analysis of gene expression arrays
